from django.apps import AppConfig


class ServiceApiConfig(AppConfig):
    name = 'service_api'
    verbose_name = 'Service API'
